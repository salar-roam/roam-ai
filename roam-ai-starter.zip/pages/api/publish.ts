import type { NextRequest } from 'next/server';
import { captureEvent } from '@/lib/validate-and-store';

export const runtime = 'edge';

export default async function handler(req: NextRequest) {
  const body = await req.json();

  const { error } = await captureEvent(body);
  if (error) return new Response(error.message, { status: 400 });

  return new Response('ok');
}
